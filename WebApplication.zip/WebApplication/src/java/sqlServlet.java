//Name: Guillermo Echarri
//Course: CNT 4714 - Spring 2019 - Project Four
//Assignment Title: A Three-Tier Distributed Web-Based Application
//Date: April 21, 2019

import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class sqlServlet extends HttpServlet {
    
    private Connection connection;
    private Statement statement;

    //connect to the database
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try{
            Class.forName(config.getInitParameter("databaseDriver"));
            connection = DriverManager.getConnection(config.getInitParameter("databaseName"), config.getInitParameter("username"), config.getInitParameter("password"));
            statement = connection.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY );
        }
        catch(Exception e){
            e.printStackTrace();
        }
	
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            String sqlStatement = " ";
            String message = " ";
            
            //get the command to execute
            sqlStatement = request.getParameter("sqlStatement");
            message = request.getParameter("message");
            
            //select
            if(sqlStatement.toLowerCase().contains("select")){
                message = getSelectQuery(sqlStatement);
            }
            else{ //insert, update, delete, etc.
                message = getUpdateQuery(sqlStatement);
            }
            
            //put message in the output of the frontend
            HttpSession session = request.getSession();
            session.setAttribute("message", message);
            session.setAttribute("sqlStatement", sqlStatement);
            
            //return back to the front end
            RequestDispatcher requestDispatcher; 
            requestDispatcher = request.getRequestDispatcher("/index.jsp");
            requestDispatcher.forward(request, response);
            
        } catch (SQLException ex) {
            //put message in the output of the frontend
            HttpSession session = request.getSession();
            session.setAttribute("message", ex.getMessage());
            session.setAttribute("sqlStatement", " ");
            //return back to the front end
            RequestDispatcher requestDispatcher; 
            requestDispatcher = request.getRequestDispatcher("/index.jsp");
            requestDispatcher.forward(request, response);
        }
    }

    private String getSelectQuery(String sqlStatement) throws SQLException {
	String message;
        
        //actually execute the query
	//save it to a table
	ResultSet table = statement.executeQuery(sqlStatement);
        //get the tables data
	ResultSetMetaData tableData = table.getMetaData();
        
        //translate table to html
	int numCols = tableData.getColumnCount();
        //style
	String tableStart = "<table style='width:50%' border='1'>";
        //make the tables head
        String tableHead = "<tr>";
	for (int i = 1; i <= numCols; i++) {
		tableHead += "<th>" + tableData.getColumnName(i) + "</th>";
	}
	tableHead += "</tr>";

	//make all the other rows
	String tableRows = "";
	while (table.next()) {
            tableRows += "<tr>";
            for (int i = 1; i <= numCols; i++) {
                    tableRows += "<td>" + table.getString(i) + "</th>";
            }
            tableRows += "</tr>";
        }

        //close table
        String tableEnd = "</table>";
        //tape it all together
        message = tableStart + tableHead + tableRows + tableEnd;

        return message;
    }
    
    private String getUpdateQuery(String sqlStatement) throws SQLException {
	String message = "Completed SQL statement: " + sqlStatement;
        int quantity = 0;
        //get quantity if it exist
        //check if update or insert
        if(sqlStatement.toLowerCase().contains("update") || sqlStatement.toLowerCase().contains("insert")){
            //check if dealing with shipments
            if(sqlStatement.toLowerCase().contains("shipments")){
                //check if quantity >=100
                String temp = sqlStatement;
                //replace all non-numbers with whitespace
                temp = temp.replaceAll("[^0-9]+", " ");
                //take the quantity number out (last one)
                Scanner scan = new Scanner(temp);
                while(scan.hasNext()){
                    quantity = scan.nextInt();
                }
            }
        }
        
        //perform the actual update
        statement.executeUpdate(sqlStatement);
        
        //if quantity of update >= 100 then increase status by 5
        if(quantity >= 100){
            statement.executeUpdate("update suppliers set status = status + 5 " +
                                   "where snum in (select snum from shipments where quantity > 100)");
        }

            return message;
    }
}
